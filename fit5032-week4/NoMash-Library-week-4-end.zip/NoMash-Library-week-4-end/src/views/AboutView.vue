<template>
    <div class="about">
      <h1>About Our Library</h1>
      <p>Welcome to our digital library! We're dedicated to providing a vast collection of books and resources to our community.</p>
    </div>
  </template>
  
  <script setup>
  // No script needed for now
  </script>
  
  <style>
  .about {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  margin-top: 20px;
  margin-left: auto;
  margin-right: auto;
  width: 100%;
}

.about h1, .about p {
  margin: 10px 0;
}
  </style>